export interface TagCount {
  tag: string
  count: number
}

export interface TagCategory {
  id: string
  name: string
  tags: string[]
  color?: string
}

export function characterIdFromActionScope(scope: string): string | null {
  const prefix = 'character-card:'
  const suffix = ':actions'
  if (!scope.startsWith(prefix) || !scope.endsWith(suffix)) return null
  const id = scope.slice(prefix.length, -suffix.length)
  return id || null
}

function folded(value: string): string {
  return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase()
}

export function normalizeTags(value: unknown): TagCount[] {
  if (!Array.isArray(value)) return []
  const seen = new Set<string>()
  const result: TagCount[] = []
  for (const item of value) {
    if (!item || typeof item !== 'object') continue
    const record = item as Record<string, unknown>
    const tag = typeof record.tag === 'string' ? record.tag.trim() : ''
    const key = folded(tag)
    if (!tag || seen.has(key)) continue
    seen.add(key)
    result.push({ tag, count: typeof record.count === 'number' && Number.isFinite(record.count) ? record.count : 0 })
  }
  return result.sort((a, b) => a.tag.localeCompare(b.tag, undefined, { sensitivity: 'base' }))
}

export function orderTagCounts(tags: readonly TagCount[], order: readonly string[]): TagCount[] {
  const ranks = new Map(order.map((tag, index) => [folded(tag), index]))
  return [...tags].sort((a, b) => {
    const aRank = ranks.get(folded(a.tag))
    const bRank = ranks.get(folded(b.tag))
    if (aRank !== undefined || bRank !== undefined) {
      if (aRank === undefined) return 1
      if (bRank === undefined) return -1
      if (aRank !== bRank) return aRank - bRank
    }
    return a.tag.localeCompare(b.tag, undefined, { sensitivity: 'base' })
  })
}

export function orderTagNames(tags: readonly string[], order: readonly string[]): string[] {
  const counts = tags.map((tag) => ({ tag, count: 0 }))
  return orderTagCounts(counts, order).map(({ tag }) => tag)
}

export function applyTagLibraryChanges(tags: readonly string[], order: readonly string[], removedTags: readonly string[], renamedTags: Readonly<Record<string, string>> = {}): string[] {
  const removed = new Set(removedTags.map(folded))
  const renames = new Map(Object.entries(renamedTags).map(([from, to]) => [folded(from), to.trim()]))
  const seen = new Set<string>()
  return orderTagNames(tags.map((tag) => renames.get(folded(tag)) || tag).filter((tag) => {
    const key = folded(tag)
    if (removed.has(key) || seen.has(key)) return false
    seen.add(key)
    return true
  }), order)
}

export function flattenCategories(categories: readonly TagCategory[]): string[] {
  const seen = new Set<string>()
  const result: string[] = []
  for (const category of categories) {
    for (const rawTag of category.tags) {
      const tag = rawTag.trim()
      const key = folded(tag)
      if (!tag || seen.has(key)) continue
      seen.add(key)
      result.push(tag)
    }
  }
  return result
}

function isUncategorized(category: TagCategory): boolean {
  return category.id === 'uncategorized' || category.name.localeCompare('Uncategorized', undefined, { sensitivity: 'base' }) === 0
}

/**
 * Chooses the category layout containing the most useful organization data.
 * This is intentionally used only while migrating legacy, unversioned saves:
 * Lumiverse may return an empty/default value even though the browser-local
 * copy still contains the user's real category assignments.
 */
export function chooseRicherCategoryLayout(candidates: readonly unknown[]): TagCategory[] {
  let best: TagCategory[] = []
  let bestScore = -1
  for (const candidate of candidates) {
    if (!Array.isArray(candidate)) continue
    const normalized = reconcileCategories([], candidate as TagCategory[])
    const named = normalized.filter((category) => !isUncategorized(category))
    const assignedOutsideFallback = named.reduce((total, category) => total + category.tags.length, 0)
    const populatedNamed = named.filter((category) => category.tags.length > 0).length
    const totalTags = normalized.reduce((total, category) => total + category.tags.length, 0)
    const score = assignedOutsideFallback * 1_000_000 + populatedNamed * 10_000 + named.length * 100 + totalTags
    if (score <= bestScore) continue
    bestScore = score
    best = normalized.map((category) => ({ ...category, tags: [...category.tags] }))
  }
  return best
}

export function reconcileCategories(library: readonly TagCount[], saved: readonly TagCategory[]): TagCategory[] {
  const ids = new Set<string>()
  const tagKeys = new Set<string>()
  const result: TagCategory[] = []
  for (const [index, category] of saved.entries()) {
    if (!category || typeof category !== 'object') continue
    let id = typeof category.id === 'string' && category.id.trim() ? category.id.trim() : `category-${index + 1}`
    while (ids.has(id)) id = `${id}-${index + 1}`
    ids.add(id)
    const name = typeof category.name === 'string' && category.name.trim() ? category.name.trim() : `Category ${index + 1}`
    const categoryTags: string[] = []
    for (const rawTag of Array.isArray(category.tags) ? category.tags : []) {
      if (typeof rawTag !== 'string') continue
      const tag = rawTag.trim()
      const key = folded(tag)
      if (!tag || tagKeys.has(key)) continue
      tagKeys.add(key)
      categoryTags.push(tag)
    }
    const color = typeof category.color === 'string' && /^#[0-9a-f]{6}$/i.test(category.color) ? category.color : undefined
    result.push({ id, name, tags: categoryTags, ...(color ? { color } : {}) })
  }
  if (!result.length) result.push({ id: 'uncategorized', name: 'Uncategorized', tags: [] })
  let uncategorized = result.find((category) => category.id === 'uncategorized' || category.name.toLocaleLowerCase() === 'uncategorized')
  if (!uncategorized) {
    uncategorized = { id: 'uncategorized', name: 'Uncategorized', tags: [] }
    result.push(uncategorized)
  }
  for (const item of library) {
    const key = folded(item.tag)
    if (tagKeys.has(key)) continue
    tagKeys.add(key)
    uncategorized.tags.push(item.tag)
  }
  return result
}

export function mergeTagLibrary(tags: readonly TagCount[], savedOrder: readonly string[]): TagCount[] {
  const byKey = new Map(tags.map((item) => [folded(item.tag), item]))
  const seen = new Set<string>()
  const result: TagCount[] = []
  for (const saved of savedOrder) {
    const tag = saved.trim()
    const key = folded(tag)
    if (!tag || seen.has(key)) continue
    seen.add(key)
    result.push(byKey.get(key) ?? { tag, count: 0 })
  }
  for (const item of tags) {
    const key = folded(item.tag)
    if (seen.has(key)) continue
    seen.add(key)
    result.push(item)
  }
  return result
}

export function mergeTagOrder(tags: readonly TagCount[], savedOrder: readonly string[]): string[] {
  return mergeTagLibrary(tags, savedOrder).map(({ tag }) => tag)
}

export function filterTags(tags: readonly TagCount[], query: string, assigned: readonly string[], order: readonly string[] = []): TagCount[] {
  const needle = folded(query.trim())
  const excluded = new Set(assigned.map(folded))
  return orderTagCounts(tags, order)
    .filter(({ tag }) => !excluded.has(folded(tag)) && (!needle || folded(tag).includes(needle)))
    .sort((a, b) => {
      if (!needle) return 0
      const aName = folded(a.tag)
      const bName = folded(b.tag)
      const aPrefix = aName.startsWith(needle)
      const bPrefix = bName.startsWith(needle)
      if (aPrefix !== bPrefix) return aPrefix ? -1 : 1
      return 0
    })
}

export function hasExactTag(tags: readonly TagCount[], query: string): boolean {
  const needle = folded(query.trim())
  return Boolean(needle) && tags.some(({ tag }) => folded(tag) === needle)
}

export interface TagGroup {
  category: TagCategory
  tags: TagCount[]
}

/**
 * Buckets an already-filtered/ordered list of tags by the category that owns
 * each tag, so a picker can render one heading per category instead of one
 * long flat list. Groups appear in first-occurrence order within `tags`,
 * which matches `categories`' own order as long as `tags` wasn't re-sorted
 * away from that (e.g. by a search query pulling prefix matches upward).
 * Any tag with no owning category (should not normally happen once
 * `reconcileCategories` has run) falls into an "Uncategorized" bucket.
 */
export function groupTagsByCategory(tags: readonly TagCount[], categories: readonly TagCategory[]): TagGroup[] {
  const owner = new Map<string, TagCategory>()
  for (const category of categories) {
    for (const rawTag of category.tags) {
      const key = folded(rawTag.trim())
      if (key && !owner.has(key)) owner.set(key, category)
    }
  }
  const fallback: TagCategory = categories.find((category) => category.id === 'uncategorized')
    ?? { id: 'uncategorized', name: 'Uncategorized', tags: [] }
  const buckets = new Map<string, TagCount[]>()
  const order: TagCategory[] = []
  for (const item of tags) {
    const category = owner.get(folded(item.tag)) ?? fallback
    if (!buckets.has(category.id)) { buckets.set(category.id, []); order.push(category) }
    buckets.get(category.id)!.push(item)
  }
  return order.map((category) => ({ category, tags: buckets.get(category.id) ?? [] }))
}
