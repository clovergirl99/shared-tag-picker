import { describe, expect, test } from 'bun:test'
import { applyTagLibraryChanges, characterIdFromActionScope, chooseRicherCategoryLayout, filterTags, flattenCategories, groupTagsByCategory, hasExactTag, mergeTagLibrary, mergeTagOrder, normalizeTags, orderTagNames, reconcileCategories } from '../src/tag-model'

test('reads the stable character id from the card action mount scope', () => {
  expect(characterIdFromActionScope('character-card:abc-123:actions')).toBe('abc-123')
  expect(characterIdFromActionScope('character-card::actions')).toBeNull()
  expect(characterIdFromActionScope('other:abc-123:actions')).toBeNull()
})

describe('normalizeTags', () => {
  test('keeps valid unique API rows and sorts them alphabetically', () => {
    expect(normalizeTags([
      { tag: 'Zeta', count: 2 },
      { tag: ' alpha ', count: 5 },
      { tag: 'ALPHA', count: 1 },
      { nope: true },
    ])).toEqual([{ tag: 'alpha', count: 5 }, { tag: 'Zeta', count: 2 }])
  })
})

describe('filterTags', () => {
  const tags = normalizeTags([
    { tag: 'Science Fiction', count: 4 },
    { tag: 'Fantasy', count: 8 },
    { tag: 'Fáe', count: 2 },
  ])

  test('shows all unassigned tags for an empty query', () => {
    expect(filterTags(tags, '', ['Fantasy']).map((item) => item.tag)).toEqual(['Fáe', 'Science Fiction'])
  })

  test('matches case- and accent-insensitively and puts prefixes first', () => {
    expect(filterTags(tags, 'fa', []).map((item) => item.tag)).toEqual(['Fáe', 'Fantasy'])
  })

  test('detects exact matches case-insensitively', () => {
    expect(hasExactTag(tags, ' fantasy ')).toBeTrue()
    expect(hasExactTag(tags, 'new tag')).toBeFalse()
  })

  test('uses the saved global order for suggestions', () => {
    expect(filterTags(tags, '', [], ['Science Fiction', 'Fantasy']).map((item) => item.tag))
      .toEqual(['Science Fiction', 'Fantasy', 'Fáe'])
  })
})

test('global order is merged with new tags and applies to character tag arrays', () => {
  const library = normalizeTags([{ tag: 'Beta', count: 1 }, { tag: 'Alpha', count: 2 }, { tag: 'New', count: 1 }])
  expect(mergeTagOrder(library, ['Beta', 'Alpha'])).toEqual(['Beta', 'Alpha', 'New'])
  expect(orderTagNames(['New', 'Alpha', 'Beta'], ['Beta', 'Alpha', 'New'])).toEqual(['Beta', 'Alpha', 'New'])
})

test('custom zero-use tags survive even when the Lumiverse API has no matching character', () => {
  const library = normalizeTags([{ tag: 'Used', count: 2 }])
  expect(mergeTagLibrary(library, ['Custom', 'Used'])).toEqual([
    { tag: 'Custom', count: 0 },
    { tag: 'Used', count: 2 },
  ])
  expect(mergeTagOrder(library, ['Custom', 'Used'])).toEqual(['Custom', 'Used'])
})

test('deleting tags removes them case-insensitively while ordering what remains', () => {
  expect(applyTagLibraryChanges(['Keep', 'DELETE ME', 'First'], ['First', 'Keep'], ['delete me']))
    .toEqual(['First', 'Keep'])
  expect(applyTagLibraryChanges(['One', 'Two'], [], ['One', 'Two'])).toEqual([])
})

test('renaming a tag updates character tags and follows the new shared order', () => {
  expect(applyTagLibraryChanges(['Old Name', 'Keep'], ['Keep', 'New Name'], [], { 'Old Name': 'New Name' }))
    .toEqual(['Keep', 'New Name'])
})

test('category reconciliation preserves custom tags and appends unassigned library tags', () => {
  const categories = reconcileCategories(
    normalizeTags([{ tag: 'Drama', count: 2 }, { tag: 'Hero', count: 1 }]),
    [
      { id: 'genres', name: 'Genres', tags: ['Drama', 'Custom'], color: '#aa33cc' },
      { id: 'characters', name: 'Character tags', tags: ['custom'] },
    ],
  )
  expect(categories[0]).toEqual({ id: 'genres', name: 'Genres', tags: ['Drama', 'Custom'], color: '#aa33cc' })
  expect(categories[1]).toEqual({ id: 'characters', name: 'Character tags', tags: [] })
  expect(categories[2]).toEqual({ id: 'uncategorized', name: 'Uncategorized', tags: ['Hero'] })
  expect(flattenCategories(categories)).toEqual(['Drama', 'Custom', 'Hero'])
})

describe('category layout recovery', () => {
  test('prefers a categorized local backup over an empty Lumiverse setting', () => {
    const recovered = chooseRicherCategoryLayout([
      [],
      [
        { id: 'stories', name: 'Story tags', tags: ['Historical', 'Fantasy'] },
        { id: 'characters', name: 'Character tags', tags: ['Royalty'] },
      ],
    ])
    expect(recovered.map((category) => category.name)).toEqual(['Story tags', 'Character tags', 'Uncategorized'])
    expect(flattenCategories(recovered)).toEqual(['Historical', 'Fantasy', 'Royalty'])
  })

  test('prefers real assignments over a flattened Uncategorized layout', () => {
    const recovered = chooseRicherCategoryLayout([
      [{ id: 'uncategorized', name: 'Uncategorized', tags: ['Historical', 'Royalty'] }],
      [{ id: 'stories', name: 'Story tags', tags: ['Historical'] }, { id: 'characters', name: 'Character tags', tags: ['Royalty'] }],
    ])
    expect(recovered.slice(0, 2).map((category) => category.id)).toEqual(['stories', 'characters'])
  })
})

describe('groupTagsByCategory', () => {
  const categories = [
    { id: 'genres', name: 'Genres', tags: ['Drama', 'Fantasy'], color: '#aa33cc' },
    { id: 'characters', name: 'Character tags', tags: ['Hero'] },
    { id: 'uncategorized', name: 'Uncategorized', tags: ['Loose'] },
  ]

  test('buckets tags under their owning category, preserving category order', () => {
    const tags = normalizeTags([
      { tag: 'Fantasy', count: 3 },
      { tag: 'Hero', count: 1 },
      { tag: 'Drama', count: 2 },
      { tag: 'Loose', count: 1 },
    ])
    const groups = groupTagsByCategory(tags, categories)
    expect(groups.map((group) => group.category.id)).toEqual(['genres', 'characters', 'uncategorized'])
    expect(groups[0]!.tags.map((item) => item.tag)).toEqual(['Drama', 'Fantasy'])
    expect(groups[1]!.tags.map((item) => item.tag)).toEqual(['Hero'])
    expect(groups[2]!.tags.map((item) => item.tag)).toEqual(['Loose'])
  })

  test('falls back an orphan tag to Uncategorized without losing it', () => {
    const tags = normalizeTags([{ tag: 'Mystery', count: 0 }])
    const groups = groupTagsByCategory(tags, categories)
    const fallback = groups.find((group) => group.category.id === 'uncategorized')!
    expect(fallback.tags.map((item) => item.tag)).toContain('Mystery')
  })

  test('omits categories with no matching tags', () => {
    const groups = groupTagsByCategory(normalizeTags([{ tag: 'Hero', count: 1 }]), categories)
    expect(groups.map((group) => group.category.id)).toEqual(['characters'])
  })
})
